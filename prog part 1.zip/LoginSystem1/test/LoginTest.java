

import loginsystem1.Login;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Login class
 * Test data matches the requirements specified in the assignment
 */
public class LoginTest {
    
    private Login login;
    
    @BeforeEach
    public void setUp() {
        login = new Login();
    }
    
    // ===== Username Tests =====
    
    @Test
    public void testCheckUserName_CorrectlyFormatted() {
        // Test Data: "kyl_1"
        login.setUsername("kyl_1");
        assertTrue(login.checkUserName(), 
            "Username 'kyl_1' should be valid (contains underscore, 5 characters)");
    }
    
    @Test
    public void testCheckUserName_IncorrectlyFormatted() {
        // Test Data: "kyle!!!!!!"
        login.setUsername("kyle!!!!!!");
        assertFalse(login.checkUserName(), 
            "Username 'kyle!!!!!!' should be invalid (no underscore, too long)");
    }
    
    @Test
    public void testCheckUserName_NoUnderscore() {
        login.setUsername("kyl1");
        assertFalse(login.checkUserName(), 
            "Username without underscore should be invalid");
    }
    
    @Test
    public void testCheckUserName_TooLong() {
        login.setUsername("kyl_e_1");
        assertFalse(login.checkUserName(), 
            "Username longer than 5 characters should be invalid");
    }
    
    // ===== Password Tests =====
    
    @Test
    public void testCheckPasswordComplexity_MeetsRequirements() {
        // Test Data: "Ch&sec@ke99!"
        login.setPassword("Ch&sec@ke99!");
        assertTrue(login.checkPasswordComplexity(), 
            "Password 'Ch&sec@ke99!' should meet all complexity requirements");
    }
    
    @Test
    public void testCheckPasswordComplexity_DoesNotMeetRequirements() {
        // Test Data: "password"
        login.setPassword("password");
        assertFalse(login.checkPasswordComplexity(), 
            "Password 'password' should not meet complexity requirements");
    }
    
    @Test
    public void testCheckPasswordComplexity_TooShort() {
        login.setPassword("Pass1!");
        assertFalse(login.checkPasswordComplexity(), 
            "Password shorter than 8 characters should be invalid");
    }
    
    @Test
    public void testCheckPasswordComplexity_NoCapital() {
        login.setPassword("password123!");
        assertFalse(login.checkPasswordComplexity(), 
            "Password without capital letter should be invalid");
    }
    
    @Test
    public void testCheckPasswordComplexity_NoNumber() {
        login.setPassword("Password!!");
        assertFalse(login.checkPasswordComplexity(), 
            "Password without number should be invalid");
    }
    
    @Test
    public void testCheckPasswordComplexity_NoSpecial() {
        login.setPassword("Password123");
        assertFalse(login.checkPasswordComplexity(), 
            "Password without special character should be invalid");
    }
    
    // ===== Cell Phone Tests =====
    
    @Test
    public void testCheckCellPhoneNumber_Valid() {
        login.setCellPhoneNumber("+27721234567");
        assertTrue(login.checkCellPhoneNumber(), 
            "Cell phone number '+27721234567' should be valid");
    }
    
    @Test
    public void testCheckCellPhoneNumber_ValidWithDifferentCountryCode() {
        login.setCellPhoneNumber("+14445556666");
        assertTrue(login.checkCellPhoneNumber(), 
            "Cell phone number with US code should be valid");
    }
    
    @Test
    public void testCheckCellPhoneNumber_InvalidNoPlus() {
        login.setCellPhoneNumber("27721234567");
        assertFalse(login.checkCellPhoneNumber(), 
            "Cell phone number without + should be invalid");
    }
    
    @Test
    public void testCheckCellPhoneNumber_InvalidTooLong() {
        login.setCellPhoneNumber("+277212345678901");
        assertFalse(login.checkCellPhoneNumber(), 
            "Cell phone number too long should be invalid");
    }
    
    // ===== Register User Tests =====
    
    @Test
    public void testRegisterUser_ValidRegistration() {
        login = new Login("John", "Doe", "jo_hn", "Password123!", "+27721234567");
        assertEquals("User registered successfully!", login.registerUser());
    }
    
    @Test
    public void testRegisterUser_InvalidUsername() {
        login = new Login("John", "Doe", "john", "Password123!", "+27721234567");
        assertEquals("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.", 
                     login.registerUser());
    }
    
    @Test
    public void testRegisterUser_InvalidPassword() {
        login = new Login("John", "Doe", "jo_hn", "password", "+27721234567");
        assertEquals("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.", 
                     login.registerUser());
    }
    
    @Test
    public void testRegisterUser_InvalidPhone() {
        login = new Login("John", "Doe", "jo_hn", "Password123!", "0721234567");
        assertEquals("Cell phone number incorrectly formatted or does not contain international code.", 
                     login.registerUser());
    }
    
    // ===== Login Tests =====
    
    @Test
    public void testLoginUser_CorrectCredentials() {
        login = new Login("John", "Doe", "jo_hn", "Password123!", "+27721234567");
        assertTrue(login.loginUser("jo_hn", "Password123!"));
    }
    
    @Test
    public void testLoginUser_IncorrectCredentials() {
        login = new Login("John", "Doe", "jo_hn", "Password123!", "+27721234567");
        assertFalse(login.loginUser("jo_hn", "wrongpassword"));
    }
    
    @Test
    public void testLoginUser_WrongUsername() {
        login = new Login("John", "Doe", "jo_hn", "Password123!", "+27721234567");
        assertFalse(login.loginUser("wronguser", "Password123!"));
    }
    
    // ===== Return Login Status Tests =====
    
    @Test
    public void testReturnLoginStatus_SuccessfulLogin() {
        login = new Login("John", "Doe", "jo_hn", "Password123!", "+27721234567");
        assertEquals("Welcome John, Doe it is great to see you again.", 
                     login.returnLoginStatus("jo_hn", "Password123!"));
    }
    
    @Test
    public void testReturnLoginStatus_FailedLogin() {
        login = new Login("John", "Doe", "jo_hn", "Password123!", "+27721234567");
        assertEquals("Username or password incorrect, please try again.", 
                     login.returnLoginStatus("jo_hn", "wrongpassword"));
    }
}