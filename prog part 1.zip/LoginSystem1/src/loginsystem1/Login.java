/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginsystem1;

import java.util.regex.Pattern;

/**
 * Login class that handles user registration and authentication
 * Reference for regex: Oracle Java Documentation - Pattern Class
 * https://docs.oracle.com/javase/8/docs/api/java/util/regex/Pattern.html
 */
public class Login {
    private String username;
    private String password;
    private String cellPhoneNumber;
    private String firstName;
    private String lastName;
    
    // Constructor
    public Login() {
        // Default constructor
    }
    
    // Parameterized constructor for registration
    public Login(String firstName, String lastName, String username, String password, String cellPhoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
    }
    
    /**
     * Method to check if username contains underscore and is no more than 5 characters
     * @return true if valid, false otherwise
     */
    public boolean checkUserName() {
        if (username == null) return false;
        return username.contains("_") && username.length() <= 5;
    }
    
    /**
     * Method to check password complexity:
     * - At least 8 characters long
     * - Contains a capital letter
     * - Contains a number
     * - Contains a special character
     * @return true if valid, false otherwise
     */
    public boolean checkPasswordComplexity() {
        if (password == null) return false;
        
        boolean hasMinLength = password.length() >= 8;
        boolean hasCapital = !password.equals(password.toLowerCase());
        boolean hasNumber = password.matches(".*\\d.*");
        boolean hasSpecial = !password.matches("[A-Za-z0-9]*");
        
        return hasMinLength && hasCapital && hasNumber && hasSpecial;
    }
    
    /**
     * Method to check cell phone number format using regex
     * Valid format: International country code followed by number (max 10 digits total)
     * South African international code is +27
     * Reference: Regular expression pattern adapted from Oracle Java Tutorials
     * https://docs.oracle.com/javase/tutorial/essential/regex/
     * @return true if valid, false otherwise
     */
    public boolean checkCellPhoneNumber() {
        if (cellPhoneNumber == null) return false;
        // Regex: starts with +, then 1-3 digits for country code, then up to 10 digits for the number
        // Pattern allows for +27, +1, +44 etc. followed by up to 10 digits
        String regex = "^\\+[0-9]{1,3}[0-9]{1,10}$";
        return Pattern.matches(regex, cellPhoneNumber);
    }
    
    /**
     * Method to return registration messages
     * @return appropriate registration message
     */
    public String registerUser() {
        boolean validUsername = checkUserName();
        boolean validPassword = checkPasswordComplexity();
        boolean validPhone = checkCellPhoneNumber();
        
        if (!validUsername) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        } else if (!validPassword) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        } else if (!validPhone) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        } else {
            return "User registered successfully!";
        }
    }
    
    /**
     * Method to verify login credentials
     * @param enteredUsername username entered at login
     * @param enteredPassword password entered at login
     * @return true if credentials match, false otherwise
     */
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return this.username != null && 
               this.username.equals(enteredUsername) && 
               this.password != null &&
               this.password.equals(enteredPassword);
    }
    
    /**
     * Method to return login status message
     * @param enteredUsername username entered at login
     * @param enteredPassword password entered at login
     * @return appropriate login message
     */
    public String returnLoginStatus(String enteredUsername, String enteredPassword) {
        if (loginUser(enteredUsername, enteredPassword)) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
    
    // Getters and Setters
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getCellPhoneNumber() {
        return cellPhoneNumber;
    }
    
    public void setCellPhoneNumber(String cellPhoneNumber) {
        this.cellPhoneNumber = cellPhoneNumber;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}