/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package loginsystem1;

import java.util.Scanner;

/**
 * Main application class for the Registration and Login System
 */
public class UserInterface {
    private static Scanner scanner = new Scanner(System.in);
    private static Login registeredUser = null;
    
    public static void main(String[] args) {
        System.out.println("=== Registration and Login System ===\n");
        
        boolean exit = false;
        while (!exit) {
            System.out.println("\n--- Menu ---");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            
            int choice = getIntInput();
            
            switch (choice) {
                case 1:
                    register();
                    break;
                case 2:
                    login();
                    break;
                case 3:
                    exit = true;
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
        scanner.close();
    }
    
    private static void register() {
        System.out.println("\n=== Registration ===\n");
        
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();
        
        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();
        
        System.out.print("Enter Username (must contain underscore, max 5 chars): ");
        String username = scanner.nextLine();
        
        System.out.print("Enter Password (8+ chars, capital, number, special char): ");
        String password = scanner.nextLine();
        
        System.out.print("Enter Cell Phone Number (with international code, e.g., +27...): ");
        String phoneNumber = scanner.nextLine();
        
        registeredUser = new Login(firstName, lastName, username, password, phoneNumber);
        
        String registrationMessage = registeredUser.registerUser();
        System.out.println("\n" + registrationMessage);
        
        if (registrationMessage.equals("User registered successfully!")) {
            System.out.println("Your account has been created!");
        }
    }
    
    private static void login() {
        if (registeredUser == null) {
            System.out.println("\nNo user registered yet. Please register first.");
            return;
        }
        
        System.out.println("\n=== Login ===\n");
        
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();
        
        String loginStatus = registeredUser.returnLoginStatus(username, password);
        System.out.println("\n" + loginStatus);
    }
    
    private static int getIntInput() {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Please enter a valid number: ");
            }
        }
    }
}